package CS203Course.Lab.Lab_4.Question_2;

interface Shape {
    public double area(); // fixme => interface method without body
}
