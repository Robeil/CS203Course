package CS203Course.Lab.Lab_1.Question_8.myutil;

 public class Person { // fixme ==> we have to make the class "PUBLIC"
    private String name;

    public Person(){
        name = "Unknown";
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }

}
