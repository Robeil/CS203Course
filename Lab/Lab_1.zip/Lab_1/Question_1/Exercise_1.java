package CS203Course.Lab.Lab_1.Question_1;

public class Exercise_1 {
    /**
     * public static void main( String[] args ) {
     * Breed persian = new Breed("Persian", 10.0);
     * Cat chacha = new Cat("Cha Cha", persian, 12.0);
     * Cat bombom = new Cat("Bom Bom", "mix", 10.0); 1 FIXME <==
     * Cat puffpuff = new Cat("Puff Puff", chacha, 9.0); 2 FIXME <==
     * double diff = chacha.getWeight()
     * - persian.getWeight();
     * System.out.println(
     * puffpuff.getBreed().getWeight());
     * }
     * }
     */
    /** fixme ==> Answer below
     * We have to create the Breed object using new keyword inside the bomobom
     * FIXME => Cat bombom = new Cat("Bom Bom", "mix", 10.0);
     *
     * The variable name chacha is already used we acn't resused again inside the puffpuff object
     * FIXME => Cat puffpuff = new Cat("Puff Puff", chacha, 9.0);
     *
     */
}
