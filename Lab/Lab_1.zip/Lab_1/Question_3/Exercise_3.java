package CS203Course.Lab.Lab_1.Question_3;

public class Exercise_3 {
    /**
     * (a). public Cat(int age) { ... }
     * public Cat(double wgt) { ... }
     *
     * (b). public Dog(String name, double weight) { ... }
     * public Dog(String name, double height) { ... }
     *
     * (c). public Dog(String name, double weight) { ... }
     * public Dog(double weight, String name) { ... }
     *
     * (d). public Cat(String name) { ... }
     * public Cat(String name, double weight) { ... }
     * public Cat(double weight) { ... }
     */

    /** FIXME ==> ANSWER BELOW
     * (a) => valid
     * (b) => Invalid
     * (c) => Valid
     * (d) => Valid
     */
}
