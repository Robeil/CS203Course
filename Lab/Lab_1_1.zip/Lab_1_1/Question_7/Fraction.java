package CS203Course.Lab.Lab_1_1.Question_7;

public class Fraction {

    private double fractionalNumber;
    private int base;
    private double decimal;

    public Fraction(int base) {
        fractionalNumber = base + (decimal / 10);
    }
}
