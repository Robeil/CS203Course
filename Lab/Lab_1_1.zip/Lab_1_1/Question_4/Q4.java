package CS203Course.Lab.Lab_1_1.Question_4;

public class Q4 {
    /**
     * (a). public void compute(int num) { ... }
     *      public int compute(double num) { ... }
     *
     * (b). public void move(double length) { ... }
     *      public void move( ) { ... }
     *
     * (c). public int adjust(double amount) { ... }
     *      public void adjust(double amount, double charge) { ... }
     *
     * (d). public void doWork( ) { ... }
     *      public void doWork(String name) { ... }
     *      public int doWork(double num) { ... }
     */
    /** fixme answer below
     * (a) => Invalid
     * (b) => Valid
     * (c) => Invalid
     * (d) => Invalid
     */
}
