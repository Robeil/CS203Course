package CS203Course.Lab.Lab_1_1.Question_6;

public class Fraction {
    private double fractionalNumber;
}
